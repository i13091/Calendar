Thanks for using the Coding4Fun Toolkit!

Migration Notes:
2.1.0 -> 2.1.1

1) Added Windows Phone 8 SL Components removed in 2.0.8 (no new functionality added)
2) Added David Anson's PlaceImage control to WinRT WP81 / Win81 
3) Added ToastPrompt to WinRT Win81	